<?php
/***************************************************************************
 *                            admin_ug_auth.php
 *                            -------------------
 *   begin                : Saturday, Feb 13, 2001
 *   copyright            : (C) 2001 The phpBB Group
 *   email                : support@phpbb.com
 *
 *   $Id: admin_ug_auth.php,v 1.13.2.5 2004/03/25 15:57:20 acydburn Exp $
 *
 *
 ***************************************************************************/

/***************************************************************************
 *
 *   This program is free software; you can redistribute it and/or modify
 *   it under the terms of the GNU General Public License as published by
 *   the Free Software Foundation; either version 2 of the License, or
 *   (at your option) any later version.
 *
 ***************************************************************************/

define('IN_PHPBB', 1);

if( !empty($setmodules) )
{
	$filename = basename(__FILE__);
	$module['Users']['Permissions'] = $filename . "?mode=user";
	$module['Groups']['Permissions'] = $filename . "?mode=group";

	return;
}

//
// Load default header
//
$no_page_header = TRUE;

$phpbb_root_path = "./../";
require($phpbb_root_path . 'extension.inc');
require('./pagestart.' . $phpEx);

$params = array('mode' => 'mode', 'user_id' => POST_USERS_URL, 'group_id' => POST_GROUPS_URL, 'adv' => 'adv');

while( list($var, $param) = @each($params) )
{
	if ( !empty($HTTP_POST_VARS[$param]) || !empty($HTTP_GET_VARS[$param]) )
	{
		$$var = ( !empty($HTTP_POST_VARS[$param]) ) ? $HTTP_POST_VARS[$param] : $HTTP_GET_VARS[$param];
	}
	else
	{
		$$var = "";
	}
}

$user_id = intval($user_id);
$group_id = intval($group_id);
$adv = intval($adv);
$mode = htmlspecialchars($mode);

//
// Start program - define vars
//
$forum_auth_fields = array('auth_view', 'auth_read', 'auth_post', 'auth_reply', 'auth_edit', 'auth_delete', 'auth_sticky', 'auth_announce', 'auth_vote', 'auth_pollcreate');

$auth_field_match = array(
	'auth_view' => AUTH_VIEW,
	'auth_read' => AUTH_READ,
	'auth_post' => AUTH_POST,
	'auth_reply' => AUTH_REPLY,
	'auth_edit' => AUTH_EDIT,
	'auth_delete' => AUTH_DELETE,
	'auth_sticky' => AUTH_STICKY,
	'auth_announce' => AUTH_ANNOUNCE, 
	'auth_vote' => AUTH_VOTE, 
	'auth_pollcreate' => AUTH_POLLCREATE);

$field_names = array(
	'auth_view' => $lang['View'],
	'auth_read' => $lang['Read'],
	'auth_post' => $lang['Post'],
	'auth_reply' => $lang['Reply'],
	'auth_edit' => $lang['Edit'],
	'auth_delete' => $lang['Delete'],
	'auth_sticky' => $lang['Sticky'],
	'auth_announce' => $lang['Announce'], 
	'auth_vote' => $lang['Vote'], 
	'auth_pollcreate' => $lang['Pollcreate']);

// ---------------
// Start Functions
//
function check_auth($type, $key, $u_access, $is_admin)
{
	$auth_user = 0;

	if( count($u_access) )
	{
		for($j = 0; $j < count($u_access); $j++)
		{
			$result = 0;
			switch($type)
			{
				case AUTH_ACL:
					$result = $u_access[$j][$key];

				case AUTH_MOD:
					$result = $result || $u_access[$j]['auth_mod'];

				case AUTH_ADMIN:
					$result = $result || $is_admin;
					break;
			}

			$auth_user = $auth_user || $result;
		}
	}
	else
	{
		$auth_user = $is_admin;
	}

	return $auth_user;
}
//
// End Functions
// -------------

if ( isset($HTTP_POST_VARS['submit']) && ( ( $mode == 'user' && $user_id ) || ( $mode == 'group' && $group_id ) ) )
{
	$user_level = '';
	if ( $mode == 'user' )
	{
		//
		// Get group_id for this user_id
		//
		$sql = "SELECT g.group_id, u.user_level
			FROM " . USER_GROUP_TABLE . " ug, " . USERS_TABLE . " u, " . GROUPS_TABLE . " g
			WHERE u.user_id = $user_id 
				AND ug.user_id = u.user_id 
				AND g.group_id = ug.group_id 
				AND g.group_single_user = " . TRUE;
		if ( !($result = $db->sql_query($sql)) )
		{
			message_die(GENERAL_ERROR, 'Could not select info from user/user_group table', '', __LINE__, __FILE__, $sql);
		}

		$row = $db->sql_fetchrow($result);

		$group_id = $row['group_id'];
		$user_level = $row['user_level'];

		$db->sql_freeresult($result);
	}

	//
	// Carry out requests
	//
	if ( $mode == 'user' && $HTTP_POST_VARS['userlevel'] == 'admin' && $user_level != ADMIN )
	{
		//
		// Make user an admin (if already user)
		//
		if ( $userdata['user_id'] != $user_id )
		{
			$sql = "UPDATE " . USERS_TABLE . "
				SET user_level = " . ADMIN . "
				WHERE user_id = $user_id";
			if ( !($result = $db->sql_query($sql)) )
			{
				message_die(GENERAL_ERROR, 'Could not update user level', '', __LINE__, __FILE__, $sql);
			}

			$sql = "DELETE FROM " . AUTH_ACCESS_TABLE . "
				WHERE group_id = $group_id 
					AND auth_mod = 0";
			if ( !($result = $db->sql_query($sql)) )
			{
				message_die(GENERAL_ERROR, "Couldn't delete auth access info", "", __LINE__, __FILE__, $sql);
			}

			//
			// Delete any entries in auth_access, they are not required if user is becoming an
			// admin
			//
			$sql = "UPDATE " . AUTH_ACCESS_TABLE . "
				SET auth_view = 0, auth_read = 0, auth_post = 0, auth_reply = 0, auth_edit = 0, auth_delete = 0, auth_sticky = 0, auth_announce = 0
				WHERE group_id = $group_id"; 
			if ( !($result = $db->sql_query($sql)) )
			{
				message_die(GENERAL_ERROR, "Couldn't update auth access", "", __LINE__, __FILE__, $sql);
			}
		}

		$message = $lang['Auth_updated'] . '<br /><br />' . sprintf($lang['Click_return_userauth'], '<a href="' . append_sid("admin_ug_auth.$phpEx?mode=$mode") . '">', '</a>') . '<br /><br />' . sprintf($lang['Click_return_admin_index'], '<a href="' . append_sid("index.$phpEx?pane=right") . '">', '</a>');
		message_die(GENERAL_MESSAGE, $message);
	}
	else
	{
		if ( $mode == 'user' && $HTTP_POST_VARS['userlevel'] == 'user' && $user_level == ADMIN )
		{
			//
			// Make admin a user (if already admin) ... ignore if you're trying
			// to change yourself from an admin to user!
			//
			if ( $userdata['user_id'] != $user_id )
			{
				$sql = "UPDATE " . AUTH_ACCESS_TABLE . "
					SET auth_view = 0, auth_read = 0, auth_post = 0, auth_reply = 0, auth_edit = 0, auth_delete = 0, auth_sticky = 0, auth_announce = 0
					WHERE group_id = $group_id";
				if ( !($result = $db->sql_query($sql)) )
				{
					message_die(GENERAL_ERROR, 'Could not update auth access', '', __LINE__, __FILE__, $sql);
				}

				//
				// Update users level, reset to USER
				//
				$sql = "UPDATE " . USERS_TABLE . "
					SET user_level = " . USER . "
					WHERE user_id = $user_id";
				if ( !($result = $db->sql_query($sql)) )
				{
					message_die(GENERAL_ERROR, 'Could not update user level', '', __LINE__, __FILE__, $sql);
				}
			}

			$message = $lang['Auth_updated'] . '<br /><br />' . sprintf($lang['Click_return_userauth'], '<a href="' . append_sid("admin_ug_auth.$phpEx?mode=$mode") . '">', '</a>') . '<br /><br />' . sprintf($lang['Click_return_admin_index'], '<a href="' . append_sid("index.$phpEx?pane=right") . '">', '</a>');
		}
		else
		{
	
			$change_mod_list = ( isset($HTTP_POST_VARS['moderator']) ) ? $HTTP_POST_VARS['moderator'] : false;

			if ( empty($adv) )
			{
				$change_acl_list = ( isset($HTTP_POST_VARS['private']) ) ? $HTTP_POST_VARS['private'] : false;
			}
			else
			{
				$change_acl_list = array();
				for($j = 0; $j < count($forum_auth_fields); $j++)
				{
					$auth_field = $forum_auth_fields[$j];

					while( list($forum_id, $value) = @each($HTTP_POST_VARS['private_' . $auth_field]) )
					{
						$change_acl_list[$forum_id][$auth_field] = $value;
					}
				}
			}

			$sql = "SELECT * 
				FROM " . FORUMS_TABLE . " f
				ORDER BY forum_order";
			if ( !($result = $db->sql_query($sql)) )
			{
				message_die(GENERAL_ERROR, "Couldn't obtain forum information", "", __LINE__, __FILE__, $sql);
			}

			$forum_access = array();
			while( $row = $db->sql_fetchrow($result) )
			{
				$forum_access$sql .ss = a.s = a.s =				{
					 )
			{
				me.s = a.s =				{
					 )
			{
				me.s = a.s =				{
					 )
			{F']['Pe.*LE . "
				WHERE group_id = $gr'Pe, ug, " . USERS_TABLE . " u, " . GRRE u.user_id= $us_id";
				AND g.grou= "UPDATE_id 
				AND g.group_single_u( !($a				AND g.group_single_u( !( TRUE;
		if ( !($result = $db-ce("RUMS_TABLE . "
				WHERE group_id = $gr'd";
				if ( !($result = $db->sq_query($sql)) )
			{
				message_die(GENERAL_ERROR, "Couldn't obtain forum information", "", _', ___, __Fp. "?mode=g, $sql);
			}

			$forum_access = array();
	 required iw = $db->sql_fetchrow($result) )
			{
				$forum_access$sql .ss = a. required i[b->sql$value;
']{
					 )
			{
				me.s = a.s =				{
					 )
			{
							while( dmin_sw = $db->sql_fe		$fielh_fiestatuiw = $db->sql_fe		$fielhPOSTstatuiw = $db->sql
	$fields); $i++)
				{
					 = a.s =			ist($key, $val) =  $value;
;

					whired i[b	}
	$value;
']m_id, $_querql = "private'] required i[b$value;
		TH_ADMIN:
	e != "($HTTP_POST_VAR[b$value;
		TH_ADMIN:
	sql = required i[b$value;
		TH_ADMIN:
	&& $grql = "pr!ivate'] required i[b$value;
		TH_ADMIN:
	e != aram]) )($HTTP_POST_VAR[b$value;
		TH_ADMIN:
	ivatql = = $forum_auth_	$fielhPOSTstatui[b$value;
	;

	($HTTP_POST_VAR[b$value;
		TH_ADMIN:
	"fontsize"uery_	$fielhPOSTstatui[b$value;
	;l_list[$forum_id				while( dmin_s[b$value;
	;

'],
	'ausql = "SELECT'send_fi pr!ivate'] required i[b$value;
		TH_ADMIN:
	e l_list[$forum_id				while( dmin_s[b$value;
	;

'", "",usql = "SELECT'send_list[$forum_id				while( dmin_s[b$value;
	;

'	$fiel'sql = "SELECT *nt($forum_auth_fields); $j++)
				{
					$auth_field = $forum_auth_fields[$j];

					while( list($forum_id, $vb_roo				whired i[b	}
			}
				}
			= $u_acces != ivate']][$auth_field] = $value;
					}
				}
	e l_list[$forum_ifi pr$change_acrequired i[b$value;
		TH_ADMIN:
	e != forum_i"private'] required i[b$value;
					}
				}
	e != "($HTTP__field] = $value;
					}
				}
		ql = required i[b$value;
					}
				}
		& $grql = " "pr!ivate'] required i[b$value;
					}
				}
	e != aram]) )($HTTP__field] = $value;
					}
				}
	e l	& $gql = " "aram]) )	$fielhPOSTstatui[b$value;
	ate_seleate_select .= '<op	$fielh_fiestatui= $value;
					}
				}
			}$param]) )	$fielhPOSTstatui[b$value;
	a	 )
	0ce( "($HTTP__field] = $value;
					}
				}
	m_id, $v_ifi private'] required i[b$value;
					}
				}
	e != ram]) )	$fielh_fiestatui= $value;
					}
				}
	e != ".			while( dmin_s[b$value;
	;!

'", "",u != ".			while( dmin_s[b$value;
	;!

'	$fiel' l_list[lect .= '<oid				while( dmin_s[b$value;
	;

'],
	'ausql = "= $lang['Thsend_fi pr!ivate'] required i[b$value;
					}
				}
	e != a( ".			while( dmin_s[b$value;
	;=

'],
	'au != ram]) )	$fielh_fiestatui= $value;
					}
				}
	e ) l_list[lect .= '<oid				while( dmin_s[b$value;
	;

'", "",usql = "= $lang['Thsend_fi private'] required i[b$value;
					}
				}
	e != aram]) )	$fielh_fiestatui= $value;
					}
				}
	e ) _list[lect .= '<oid				while( dmin_s[b$value;
	;

'	$fiel'sql = "= $lang['T			$s_templa fi pr$change_acrequired i[b$value;
		TH_ADMIN:
	e != forum_i"private'] required i[b$value;
					}
				}
	e != "($HTTP__field] = $value;
					}
				}
		=l = required i[b$value;
					}
				}
		& e != ".			while( dmin_s[b$value;
	;=

'],
	'au ate_select .= '<op				while( dmin_s[b$value;
	;

'	$fiel'sql = "=plate_select .= '< entries in auttableemov" =>te, meady $fiel editDBntries in $ES" => $qser' )
	{$value) = @each($HTTP_POSTdmin_s['private_'				while( dmin_ss$sql .ss = a != $udmin_sw 

'],
	'au ate_seum_auth_ES" => $qseize")rootS" => $qse!

'		 )
	{
	
ce('		 ). h($HTTP_P = $lang['A// Nope, no names != $udmin_sw 

'", "",u e_select .= '<opt= a.[$j];

''sql = "=pt= a
			$;

''sql = "=alue)  = @eachile( s_admin_VARS['private_'	$fielh_fiestatui= $value;
	) ate_select .= '<opt= a.[$j];ize")root= a.[$j];!

'		 )
	{
	
ce('		 ). hile( s_ad;t .= '<opt= a
			$;ize")root= a
			$;!

'		 )
	{
	
ce('		 ). h
			$sql = "als[$i] . "'"a.[$j];ize")root= a.[$j];!

'		 )
	{
	
ce('		 ). TH_ADMIN:
sql = "=pt= a
			$;ize")root= a
			$;!

'		 )
	{
	
ce('		 ). ( pr!ivate']	$fielhPOSTstatui[b$value;
	a	 )
	0ce(]	$fielhPOSTstatui[b$value;
	am_id, $v_HEMES_NAME_TABLE . " (th	WHERE group_id = $gr'(($HTTP_POS	FROM " . ot= a.[$j]) _list[le	for($i =($HTTP_POST	FROM " . ot= a_VARS[{
						$values[] = "'" . str_replt= a_VARSs;

''sql = "=alue)  = @eachile( s_admin_VARS['private_'	$fielh_fiestatui= $value;
	) ate_select .= '<opt= a_VARSs;ize")root= a
			$s;!

'		 )
	{
	
ce('		 ). hile( s_ad). T;

'). h
			$sql = "als[$i] . "'"a_VARSs;ize")root= a
			$s;!

'		 )
	{
	
ce('		 ). TH_ADMIN:;

'). ( pr!ivate']	$fielhPOSTstatui[b$value;
	a	 )
	0ce(]	$fielhPOSTstatui[b$value;
	am_id, $v_HEMES_NABLE . "
					SET auth_view = 0,  _list[le . "ot= a
			$s;_list[led 
					AND auth_mod = 0";
			if 	f ( !($value;
;

					wh $db->sqlals[$i] 
{
	$($sql)) )
				{
					message_die(GENERAect .= '<, "Couldn't update auth access", "", __LINE_ )
				__LINE_p. "?mode=g, $sql);
			}

			$forum_access = arr_select .= '< entri != $utS" => $qse!

'		 , $val) =  TH_ACCESS_TABLE . "
				WHERE group_id = $gr$style_id";
			AND auth_mod = 0";
			if 	( !($value;
;INi =tS" => $qs)>sql_queryry($sql)) )
				{
					message_die(GENERAL_ERROR, 'Could not update user leess info", "", __p. "?mode=they are, $sql);
				}
				
				if ( $selected_nameay();
	l_ = 0, aEnd Fs = a.s =				{
					 )
	uth'], '<a href="' . append_sice(]th'], '<a href="' .od = end_siql_fe	ated'] . '<br /><br />' . sprintf($lang['Click_return_useraut_ = 0, aEnd d("admin_ug_auth.$phpEx?mode=$mode") . '">', '</a>') . '<br /><br />' . sprintf($lang['Click_return_admin_index'], '<a href="' . append_sid("index.$phpEx?pane=right") . '">', '</a>');
		}
		else
		{
	
			$change_m
min (if alULINE__, __FILE__editIN:;sql panron_a USER
			
eme InfoM " . FORUMS_TAp_id = ug.grouE . "
				WHERE group_id = $gr'Pe, ug, " . USERS_TABLE . " u, " . GROUPS_TABLE . " g
 .grouid";
						AND auth_$a				AND g.
if 	( !(	AND ug.user			AND g.gr
if 	( !(	AND ugILE__eNOT;INi . GRMOD. " ,user_id = $use) _lisSERS_ !($p_id = ug.grouHAVING SUM($a	H_ADMIN:) ", ">sql_query($sql)) )
		{
			message_die(GENERAL_ERROR, 'Could not select info frformation", "", _', ___, __Fp. "?mode=g, $sql);
			}

			$forum_access = arth_updbodyIN:;

''sql tchrow($result) )
			{
				$forum_access$sql SERS_TAodyIN:;ize")rootodyIN:;!

'		 )
	{
	
ce('		 ). h->sql_freew['user__nam	me.s = a.s =				{
					 )
			{
	n (if alULINE__, __FILE__edit, __Fsql panron_a USER
			
eme Infose AUT)roSQL_LAYER$sql SERS_sult ' autg			ql':l) =  TH_ACCERUMS_TAp_id = ug.grouLE . " ug, " . _TABLE . " g
			WHE" . USERS_TABLE . " u, " . GR	WHERE group_id = $gr'Pestyle_id";
				AND g.group_id = ug.groupf ( !($a				AND g.group_single_ugroupf ( !(	AND ugILE__eNOT;INi . GRid = $us,user_id = $use)groupfSERS_ !($p_id = ug.grououHAVING SUM($a	H_ADMIN:) e(GEgrououUNIONi 
ist[le .MS_TAp_id = ug.ugroupf  . " ug, " . _TABLE . " g
ugroupf id";
	NOT;EXISTSuerql = "le .MS_TA$a	H_ADMIN:rql = "le . " ug, " . USERS_TABLE . " u, " . GR	WHERE group_id = $gr'Pe;_list[led 
						AND g.group_id = ug.groupf f ( !($a				AND g.group_single_te_seleate_sele( !(	AND ugILE__eNOT;INi . GRid = $us,user_id = $use).ugroupf SERS_ !($p_id = uggroupf)>sql_qur = $auth_sult 'or_fie':l) =  TH_ACCERUMS_TAp_id = ug.grouLE . " ug, " . _TABLE . " g
			WHE" . USERS_TABLE . " u, " . GR	WHERE group_id = $gr'Pe style_id";
				AND g.group_id = ug(+)groupf ( !($a				AND g.group_single_(+)ugroupf ( !(	AND ugILE__eNOT;INi . GRid = $us,user_id = $use)groupfSERS_ !($p_id = ug.grououHAVING SUM($a	H_ADMIN:) e(G>sql_qur = $auth_ECT themes_=  TH_ACCERUMS_TAp_id = ug.grouLE . " ")ro. GROUPS_TABLE . " g
 .grou		LEFT JO= $	WHE" . USERS_TABLE . " u,  ONi			AND g.group_id = ug.).grou		LEFT JO= $	WHE	WHERE group_id = $gr'Pe ONi$a				AND g.group_single_u) style_id";
		AND ugILE__eNOT;INi . GRid = $us,user_id = $use)groupfSERS_ !($p_id = ug.grououHAVING SUM($a	H_ADMIN:) e(G>sql_qur = $auth}sql_query($sql)) )
		{
			message_die(GENERAL_ERROR, 'Could not select info frformation", "", _', ___, __Fp. "?mode=g, $sql);
			}

			$forum_access = arth_updunbodyIN:;

al($u tchrow($result) )
			{
				$forum_access$sql SERS_TunbodyIN:;ize")roounbodyIN:;!

'		 )
	{
	
ce('		 ). h->sql_freew['user__nam	me.s = a.s =				{
					 )
			{
	b->sql_fdyIN:;!

'		 ql SERS_TABLE . " 
				SET user_style = " . $board_config	WHERE user_MOD. " $style_id";
			if;
;INi =_fdyIN:)sql_queryry($sql)) )
			{
				message_die(GENERAL_ERROR, "Couldn't update auth access", "", __LINE_, __FILE__, $sql);
			}
		}

		$message = $lang['Auth_up != $usnbodyIN:;!

'		 ql SERS_TABLE . " 
				SET user_style = " . $board_config	WHERE user_id = $us$style_id";
			if;
;INi =snbodyIN:)sql_queryry($sql)) )
			{
				message_die(GENERAL_ERROR, "Couldn't update auth access", "", __LINE_, __FILE__, $sql);
			}
		}

		$message = $lang['Auth_upGE, $message);
	}
	else
	{
		if ( $mode == }
mpla fi pr$cPOST_VARS['userleveprivate']) ) ? $HTTP_POST'use_templaod'];
d = ug.).& $group_id ) ) )
{
	$user_level = '';
	T_VARS[$pivate']) ) ? $HTTP_POST'use_templaoHTTP_POS= "S_ser_id ))
	godyser_id )']) ) ? $HTTP_POST'use_templ, trut:
		
fi pr!iv_ $db->S= "S_ser_id )NERAL_ERROR, 'Could not select te_dir']);
			}
			sucions
/emplate->sed);
$group_S= "S_ser_id )ql_freew['userests
	//
	iFrontthedts
	//M " . FORUMS_TABLE . f
				ORDER BY forum_order";
	if ( !($result = $db->s_query($sql)) )
		{
			message_die(GENERAL{_upGE, $message);
	}
	eorum information", "", __LINE__, __FILE__, $sql);
			}

			$forum_access = aests			while( $row = $db->sql_tchrow($result) )
			{
				$forum_access$sqlP_POSs = a.s =				{
					 )
	->s	me.s = a.s =				{
					 )
			{
eryrhange_acl_list P_POields); $i++)
				{
					 = a.s =			ist($key, $SERS_T$value;
;

					whired i[b	}
	$value;
']m_id, '				while( ILE__[b$value;
	;

	WHERELLql
	$fieldsauth_fields); $j++)
				{
					$auth_field = $foss = a.s = a.s =				b	}
					while( list($foruntf($ :e('b->sql_quer.s = a.s =				b	}
					while( list($forunt	= $u_acces ate_seum_auth_				while( ILE__[b$value;
	;

	WHERECL;m_auth_				while( ILE__ list($fo$value;
		];

					while( list($forum_		ed_nameayser = $//M " . FORUMS_TAp_id = ug. USER_G " . T	AND ugILE__,
			FROM " . 			FROM  " . T TRUE;
		if ( !($res . " ug, " . _TABLE . " g
			WHERE u.user_id = $us			WHE" . USERS_TABLE . " u, 'd";
		rmiss$qseize")a.s =				{
					 )
			AND ug.user_id = u.ud 
				AND g.group_id = ug._id 
				AND g.group_single_"ce("
				AND g.gr$_single_u( !(					AND auth_up_single_u( !(	AND ug.user			AND g.gb->s_query($sql)) )
		{
			message_die(GENERAL{_upGE, $message);
	}
	eorum information", "", _', ___, __F_, __FILE__, $sql);
			}

			$forum_access = aesed)g			$tw = $db->sql_tchrow($result) )
			{
				$forum_access$sqlP_POS)g			$t	{
					 )
	->s	me.s = a.s =				{
					 )
			{
		me.s = a.s =				{
					 )
			{F']['Pe.* T TRUE;
		if ( !($res . " ug, 	WHERE group_id = $gr'Pe, ug, " . USERS_TABLE . " u, " . GRRE u.user_id= $us_id";
				AND g.grou= "UPDATE_id 
				AND g.group_single_u( !($a				AND g.group_single_u( !( TRUE;
		if ( !($resul1"ce("RUMS_TABLE . "
				WHERE group_id = $gr'd";
				if ( !($result = $db->_query($sql)) )
		{
			message_die(GENERAL{_upGE, $message);
	}
	eorum information", "", _', ___, __Fp. "?mode=g, $sql);
			}

			$forum_access = a $//M required iw = $db->sql_M required i_; $j+w = $db->sql_tchrow($result) )
			{
				$forum_access$sqlP_POS required i[b->sql$value;
']{	{
					 ) _POS required i_; $j+[b->sql$value;
']{++)
	->s	me.s = a.s =				{
					 )
			{
	th_user;.s = a.s =				{
					 )
	")rooug			$t	0]ql_freeresult(// Make ad
		{
g			$t	0]ql_free			$sql ANONYMOUS	 )
	1ce(0 S['s )
	{ields); $i++)
				{
					 = a.s =			ist($key, P_POSs = a.;
;

					whired i[b	}
	$value;
']m_id,snbod($ors h_fiesumask(plateieldsauth_fields); $j++)
				{
					$auth_field = $fSERS_T{
		

					while( list($forum_		e$
			$;

.s = a.s =				b	}
	
					$resse AUTH h
			$ENERAL_ERRORsult = $resLss[$j][sult = $reREG|| $is_anctiong[b$value;
			
			sul1;m_authql = "SEL	sult = $u_access[$j][$knctiong[b$value;
			
			sul$param]) ) required i_; $j+[b$value;
	a	 )
	u_access, $$u_accesmin)
{
	$ required i[b$value;
	r = 0;

	if(['s )
$j][$knctioth_vie_fi[b$value;
			
			sulknctiong[b$value;
			
			"fontsize"uerivate']ors h_fiesumask(p l_list[$forum_ifi pr]ors h_fiesumask(	ql = requng[b$value;
			
			s!= ram]) )cl_list = 	lect .= '<op = htm1;m_auth=plate_sel
$j][$kors h_fiesumask(	ulknctiong[b$value;
			
			"fontsizql = "SEL	sult = $u_aclt || $u_acnctiong[b$value;
			
			sul$param]) ) required i_; $j+[b$value;
	a	 )
	u_access, $$u_aclt min)
{
	$ required i[b$value;
	r = 0;

	if(['s )
$j][$ql = "SEL	sult = $u_accult || $is_anctiong[b$value;
			
			sul	}

			$auth_user = $auth_usECT themes_= _anctiong[b$value;
			
			sul )
$j][$ql = "Sang['Auth_upn (if alIsy user) if ( empt?_upn (ifanctiong[b$value;
		TH_ADMIN:
	&ul$param]) ) required i_; $j+[b$value;
	a	 )
	u_access, $$u_aclt miTH_ADMIN:

	$ required i[b$value;
	r 0(['s )
$}( iss); $i+
	@$sql (anctiongsql_tchrow( @each($HTTP_POST_freeary['private_'nctiongs$sqlP_PO			$change_acl_list ={
sql_quer.s = a.sle( ILE__[b$value;
	;
= $u_acces ate_sss = a. llowedhtm1;ms = aieldsauth_fields); $j++)
				{
				ILE__ list($fo$value;
	_field = $forum_authe"uery_nctiong[b$value;
							while( ILE__ list($fo$value;
		orunte_select .= '<op llowedhtm )
$j][$SELECT *nt($f$.
 *
 templ_fi emplate">';
				w )
				['). h($HTTP_Ptf($]readd->sql_quer.th_user;.d'];
d = ary	TH_ADMIN:
	&&te_seum_auth_.
 *
 templ_fi ile . '">' . $file 1n";
			br /><bllowed_AILE__,ntf($l
				$s_' = $lang['A// No  != $udllowedh&te_seum_auth_.
 *
 templ_fi ile . '">' . $file 1n__LINE__,<inpINE__,n";
			br /><bllowed_AILE__,ntf($l
				$s_. '">' . $file 0n";/>' . $s_hisallowed_AILE__,ntf($l
				$s_' = $lang['A// Note_seum_auth_.
 *
 templ_fi ile . '">' . $file 1n";
			br /><bllowed_AILE__,ntf($l
				$s_. '">' . $file 0n__LINE__,<inpINE__,n";
			br /><hisallowed_AILE__,ntf($l
				$s_' = $langnt($f$.
 *
 templ_fi lse
			{
				message_die(GENERAL_MESSA$.
 *
 templ_fi emp&nbsp;'"Sang['Authe user has conieldsauth_fields); $j++)
				{
ult = 0;
			swit.ss = a != $us = a.s =				bj}
	$value;
']	=l =($HTTP_Pt&te_seum_authieldskuth_fiekds); $j++)
				{
					$auth_fiekd = $for[$forum_id	h_view' =	

					while( list($fok	m_id, $v_b_roo				whired i[bMOD:	h_view' =nt	= $u_acces ate_select .= '<op.
 *
 templ_fi_usv[b$value;
			
] emplate">';
				w )
				_;
					_view' =	f($['). h($HTTP_Ptf($]readd->sql$v_b_roivate'] requth_vie_fi[b$value;
				h_view' =ne != a(.th_user;.d'];
d = ary	TH_ADMIN:
	) l_list[lect .= '<oi($styl requth_vie_fi[b$value;
				h_view' =n l_list[leect .= '<oiop.
 *
 templ_fi_usv[b$value;
			
] ile . '">' . $file 1n";
			br /><ON,ntf($l
				$s_. '">' . $file 0n__LINE__,<inpINE__,n";
			br /><OFF,ntf($l
				$s_' = $la $lang['A/['A// Note_se[leect .= '<oiop.
 *
 templ_fi_usv[b$value;
			
] ile . '">' . $file 1n__LINE__,<inpINE__,n";
			br /><ON,ntf($l
				$s_. '">' . $file 0n";
			br /><OFF,ntf($l
				$s_' = $la $lang['A/['A$lang['Thsend_list[lect .= '<oi($st.th_user;.d'];
d = ary	TH_ADMIN:
	&&te_se[leect .= '<oiop.
 *
 templ_fi_usv[b$value;
			
] ile . '">' . $file 1n";
			br /><ON,ntf($l
				$s_' = $la $lang['A/['A// Note_se[leect .= '<oiop.
 *
 templ_fi_usv[b$value;
			
] ile . '">' . $file 1n";
			br /><ON,ntf($l
				$s_. '">' . $file 0n__LINE__,<inpINE__,n";
			br /><OFF,ntf($l
				$s_' = $la $lang['A/['A}
t .= '<op.
 *
 templ_fi_usv[b$value;
			
] lse
			{
				mesm_auth=plate_selte_selte_['Auth_upd.
 *
 templIN:;

'late">';
				wif ( empt['). h($HTTP_Ptf($]readdupd.
 *
 templIN:;ize")a
d = ary	TH_ADMIN:
	&&)
	{. '">' . $file 1n__LINE__,<inpINE__,n";
			br /><Is_Mf ( empty($f($l
				$s_. '">' . $file 0n";
			br /><Not_Mf ( empty($f($l
				$s_
ce('. '">' . $file 1n";
			br /><Is_Mf ( empty($f($l
				$s_. '">' . $file 0n__LINE__,<inpINE__,n";
			br /><Not_Mf ( empty($f($l
				$s_
ddupd.
 *
 templIN:;ize
			{
				mesm_a) ? $theme['td_cl ass1'] a	 )
	' ? 2
ce(' ? 1
ddupd ? $theme['td_co ass1'] a	 )
	eme['td_color2'];
			$row_class = ( !($i % 
_vars("styles", array(
				"ROW	$valu_, $ $row_clas'
				"STY($var,#'). h->s=> $style_r'
				"ROW'COLOR" => $row_colo'DER Bi]['t'COLOR				whired i[b	}
	$valueIT" => appen'U_DER Bi$u_a'les.$phpEx?mode=delete$valu. '">', '</afhemes_				whired i[b	}
	$value;
']) appen'Sclt elect)
'COLOR.
 *
 templIN:&te_			{
	b-styl = h= $fSERS_Trs("styles", array(
				"ROW	$valu_._fi
			$s, $ $row_clasn'Scceselect)
'COLOR.
 *
 templ_fi&te_splate->set_filenames(ieldsauth_fields); $j++)
				{
					$auth_field = $foss = a.rs("styles", array(
				"ROW	$valu_._fi
			$s, $ $row_clasnn'Scceselect)
'COLOR.
 *
 templ_fi_usv[b$value;
			j	ate_se $lang['Auth_updi++)
	->s@$sql (anctiona['u;( is
		//
		// Get group_id for $dyser_w' =	

	
g			$t	0]ql_freIT" =>ddupdS_ser_ s_ad)=uer.th_user;.&)
	{.ate">';
				w$user_lev"_. '">' . $file user;n__LINE__,<inpINE__,n";
			br /><bctioA" => $$f($l
				$s_. '">' . $file $usen";
			br /><bctioUs
/em$f($l
				$s_.		{
				mce('.ate">';
				w$user_lev"_. '">' . $file user;n";
			br /><bctioA" => $$f($l
				$s_. '">' . $file $usen__LINE__,<inpINE__,n";
			br /><bctioUs
/em$f($l
				$s_.		{
				m; = $is_admin;
	}t.od = w' =	

	
g			$t	0]ql	FROM  " .'userests$w' =	

 $db->sql_Mauth_$$db->sql_ields); $i++)
				{
				
g			$tist($key, P_POb-st$cPOST_VARS['userleve!	
g			$t	b	}
	RUE;
		if ( !($re
	&& $grp_id ) ) )
{
	$us= $fSERS_Tw' =[]Fs = a.s =				{
					 )
	u
g			$t	b	}
	RUE;
	 " .'uce( "
g			$t	b	}
	_freIT" =>ddup_Mau[]Fs = a.s =				{
					 )
	id = intvg			$t	b	}
	RUE;
	_VARS['style_id'
g			$t	b	}
	_fre_ )
		{
		r = $//
		for($j =IT" )_id for $dyser_RUE;
	j = 0; ''sql ields); $i++)
				{
				
g			$tist($key,  SERS_TugFs = a.s =				{
					 )
		RUE;
rowse;
		 'adv');

whilece('
			rowse;
		 'advPOST_GROUlock_varyser_RUE;
	j = 0ize")rooryser_RUE;
	j = 0!

'		 )
	{
	
ce('		 ). Tadmin_ug_auth.$phpEx?mode=$mode") . '">', '</a>') . ughemes_au[b	}else
		{mes_w' =[b	}$f($l
a_
ddupr = $is_admin;
	}dyser_RUE;
	j = 0; 	br /><Non.'userests$i_; lumn_spa;.s 2; hemewo ; lumns alwaye; ysql anyb-styl = h= ${
_vars("styles", array(
				"ROW	_fis_ad, $ $row_clas'L_UGcceseTYPEuth_announce'i" =>_ . "?mode= 0; $i < co$i_; lumn_spa;++)
	->ss_admin;
	ields); $i++)
				{
					 = a.s					$auth_fie$key,  SERS_Tcell_titresultth_view' =>
					while( list($foi]block_vars("styles", array(
				"ROW	_fis_ad, $ $row_class'L_UGcceseTYPEuth_ancell_titre&te_splateo$i_; lumn_spa;++)
		r = $//
	//
	iDum_F_, yourparar = TRUing
' && $Hin.'.$phpEx);
} = TRU                  
(array(
			"body" => "admin/styles_ist_body.t'       ctionglate->ass'&te   
(a = _se AUT)=	$change_acl_lis)
	1ce(0ql_Muonglse AUT)=	$ca.s =				{
					 )
	 'advPOST_GROU $grhemes_ "UPDATE:	 'adv');

whilec$grhemes_RUE;
	_Vmiss$e AUT_mode);
.$phpEx?mode=$mode") . '">', '</a>') . '<brrowseemes_ onglse AUT)$grrowsecl_=a = _se AUTse "ds$e AUT_mode_fg\")=	$change_acl_lis)
		br /><bdvanced_modesice(]th'], 'i" =>_modesiql_Muo$e AUT_mode);
Tadmin_ug_auths$e AUT_mode)se
		{mes_$e AUT_mode_fg\")f($l
a_
ddts$i_ype="hidden" name="mode" value="'.$mode.'" /><input type="mes_mode)se
	ame="style_id" value="'.$stylecl_put type="mes_ = hse
	ame';ts$i_ype="hidden" nize")a.s =				{
					 )
	e="mode" value="'.$mode.'" /;
		 'advPOST_GROUhse
	at type="mes_ "UPDATEse
	ame'ce('."mode" value="'.$mode.'" /;
		 'adv');

whilec$g
	at type="mes_		if ( !(se
	ame';tis
		//
		// Get group_id for $ds("styles", array(
				"ROW	$e AUT_
d = and_s $ $row_)ars(array(
			"L_STYLES_TITLE" => $lang'POST]['t'COLORdyser_w' =,lang'POST_LEVELuth_announceUs
/_Lesult(/$gr':lt_styS_ser_ s_ad,lang'POST_SERS_TMEMBST_HIPSuth_announce $fil_membership_,ntf($ce('_stydyser_RUE;
	j = ; $i < c $is_admin;
	}ds("styles", array(
				"ROW_Ce AUT_RUE;
	and_" $ $row_)ars(array(
			"L_STYLES_TITLE" => $lang'POST]['t'COLORdyod = w' =,lang'SERS_TMEMBST_HIPuth_announceUs
/g$fil_members,ntf($ce('_stydyser_RUE;
	j = ; $i < c $
rray(
			"L_STYLES_TITLE" => $lan'L_UOST_OT_SERS_]['t'COLO= a.s =				{
					 )
	uth'], UfreIT" =>ce(]th'], GUE;
	 " .'u appe'L_$u_acdmin''COLO= a.s =				{
					 )
	uth'], bctioControloUs
/em$:	uth'], bctioControloGUE;
> $sty'L_$u_acEXPLAIN'COLO= a.s =				{
					 )
	uth'], Ufrehile( > $lang['ce(]th'], GUE;
	ile( > $lang['$sty'L_lt ERATOT_STATUSuth_announceMf ( emptTstatui['$sty'L_PERMISSIONSuth_announce . "?mode=gro$sty'L_SUBMITuth_announce''user' $sty'L_RESETth_edit' => $lbod> $lany'L_DER Bth_edit' => F			w> $la
en'U_UOST_OT_SERS_'les.$phpEx?mode=delete") . '">', '</ => $h'U_SWITCaclt t'COLORuo$e AUT_mode appe'nd_sLUMN_SPAN'COLO$i_; lumn_spa;,ppe'nd$u_acceie(G'les.$phpEx?mode=delete") . '">', '</ => ppe'nd_fields)
			)'COLO$i_$template->ppars     s_adm{//
	//
	iSte">';a_', ___, __' && $Hin.'.$phpEx);
} = TRU                  
(array(
			"body" => "admin/styles_'ate-'COLO= a.s =				{
					 )
	'      ser_ 	{
			late->ass'ce('       ctio	{
			late->ass'&te   
(
		//
		// Get group_id for $ds("styles", arraTITLE" => $lang'L_DIND_POST]['t'COLORt' => FiEx?'use_templ,appen'U_SEARCacPOST'les.$phpEx?mode=..		{arc">', '</a>') .	{arc"$usen); $i < c $is_admin;
	} u.user_level
	FROM " . 	UE;
	 " .ppenE . "
			RE u.user_id = $ppend";
				if (	if ( !($res<>lt = $db->sql_query($sql)) )
		{
			message_die(GENERAL_ERROR, 'Could not select info frformation"g_id
		//( @ea, $sql);
			}

			$forum_access = arth_up
		//
result) )
			{
				$forum_access$sql SERS_TAo
			lj = 0; '.ate">';
				w;
		 'adv');

whilec$g
	_' = $ldo $foss = a.Ao
			lj = 0ile . '">' . $file '). h->s
	RUE;
	_VAR)se
		{mes_->s
	RUE;
	IT" =>cf($l
				$s_' = $lelte_alue)  =
result) )
			{
				$forum_access$s;ERS_TAo
			lj = 0lse
			{
				messa}s(array(
			"L_STYLES_TITLE" => $lang'nd$u_aclect)
'COLORAo
			lj = ; $i < c $
rri_ype="hidden" name="mode" value="'.$mode.'" /><input type="mes_mode)se
	ame
ddts$l s_ad)=uer..s =				{
					 )
	'POST'le('$u_a';$
rray(
			"L_STYLES_TITLE" => $lan'L_;
			b s_ad). Tcdmin''COLO= a.s =				{
					 )
	uth'], bctioControloUs
/em$:	uth'], bctioControloGUE;
> $sty'L_;
			b s_ad). TcEXPLAIN'COLO= a.s =				{
					 )
	uth'], Ufrehile( > $lang['ce(]th'], GUE;
	ile( > $lang['$sty'L_;
			b s_ad). Tclect)
'COLO= a.s =				{
					 )
	uth'], Ste">'_aoUs
/em$:	uth'], Ste">'_aoGUE;
> $sty'L_LOOK_S_'les.= a.s =				{
					 )
	uth'], Look_;
	Us
/em$:	uth'], Look_;
	GUE;
> $sppe'nd_fields)
			)'COLO$i_$template->pp> ppe'nd;
			b s_ad). Tcceie(G'les.$phpEx?mode=delete") . '">', '</ =&te   
r_id	
		break;
}

if 'ate-'s) )
in.'.$phpEx);
}

