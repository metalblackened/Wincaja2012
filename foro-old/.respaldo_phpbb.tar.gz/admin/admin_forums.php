<?php
/***************************************************************************
 *                             admin_forums.php
 *                            -------------------
 *   begin                : Thursday, Jul 12, 2001
 *   copyright            : (C) 2001 The phpBB Group
 *   email                : support@phpbb.com
 *
 *   $Id: admin_forums.php,v 1.40.2.10 2003/01/05 02:36:00 psotfx Exp $
 *
 ***************************************************************************/

/***************************************************************************
 *
 *   This program is free software; you can redistribute it and/or modify
 *   it under the terms of the GNU General Public License as published by
 *   the Free Software Foundation; either version 2 of the License, or
 *   (at your option) any later version.
 *
 ***************************************************************************/

define('IN_PHPBB', 1);

if( !empty($setmodules) )
{
	$file = basename(__FILE__);
	$module['Forums']['Manage'] = $file;
	return;
}

//
// Load default header
//
$phpbb_root_path = "./../";
require($phpbb_root_path . 'extension.inc');
require('./pagestart.' . $phpEx);
include($phpbb_root_path . 'includes/functions_admin.'.$phpEx);

$forum_auth_ary = array(
	"auth_view" => AUTH_ALL, 
	"auth_read" => AUTH_ALL, 
	"auth_post" => AUTH_ALL, 
	"auth_reply" => AUTH_ALL, 
	"auth_edit" => AUTH_REG, 
	"auth_delete" => AUTH_REG, 
	"auth_sticky" => AUTH_MOD, 
	"auth_announce" => AUTH_MOD, 
	"auth_vote" => AUTH_REG, 
	"auth_pollcreate" => AUTH_REG
);

//
// Mode setting
//
if( isset($HTTP_POST_VARS['mode']) || isset($HTTP_GET_VARS['mode']) )
{
	$mode = ( isset($HTTP_POST_VARS['mode']) ) ? $HTTP_POST_VARS['mode'] : $HTTP_GET_VARS['mode'];
}
else
{
	$mode = "";
}

// ------------------
// Begin function block
//
function get_info($mode, $id)
{
	global $db;

	switch($mode)
	{
		case 'category':
			$table = CATEGORIES_TABLE;
			$idfield = 'cat_id';
			$namefield = 'cat_title';
			break;

		case 'forum':
			$table = FORUMS_TABLE;
			$idfield = 'forum_id';
			$namefield = 'forum_name';
			break;

		default:
			message_die(GENERAL_ERROR, "Wrong mode for generating select list", "", __LINE__, __FILE__);
			break;
	}
	$sql = "SELECT count(*) as total
		FROM $table";
	if( !$result = $db->sql_query($sql) )
	{
		message_die(GENERAL_ERROR, "Couldn't get Forum/Category information", "", __LINE__, __FILE__, $sql);
	}
	$count = $db->sql_fetchrow($result);
	$count = $count['total'];

	$sql = "SELECT *
		FROM $table
		WHERE $idfield = $id"; 

	if( !$result = $db->sql_query($sql) )
	{
		message_die(GENERAL_ERROR, "Couldn't get Forum/Category information", "", __LINE__, __FILE__, $sql);
	}

	if( $db->sql_numrows($result) != 1 )
	{
		message_die(GENERAL_ERROR, "Forum/Category doesn't exist or multiple forums/categories with ID $id", "", __LINE__, __FILE__);
	}

	$return = $db->sql_fetchrow($result);
	$return['number'] = $count;
	return $return;
}

function get_list($mode, $id, $select)
{
	global $db;

	switch($mode)
	{
		case 'category':
			$table = CATEGORIES_TABLE;
			$idfield = 'cat_id';
			$namefield = 'cat_title';
			break;

		case 'forum':
			$table = FORUMS_TABLE;
			$idfield = 'forum_id';
			$namefield = 'forum_name';
			break;

		default:
			message_die(GENERAL_ERROR, "Wrong mode for generating select list", "", __LINE__, __FILE__);
			break;
	}

	$sql = "SELECT *
		FROM $table";
	if( $select == 0 )
	{
		$sql .= " WHERE $idfield <> $id";
	}

	if( !$result = $db->sql_query($sql) )
	{
		message_die(GENERAL_ERROR, "Couldn't get list of Categories/Forums", "", __LINE__, __FILE__, $sql);
	}

	$cat_list = "";

	while( $row = $db->sql_fetchrow($result) )
	{
		$s = "";
		if ($row[$idfield] == $id)
		{
			$s = " selected=\"selected\"";
		}
		$catlist .= "<option value=\"$row[$idfield]\"$s>" . $row[$namefield] . "</option>\n";
	}

	return($catlist);
}

function renumber_order($mode, $cat = 0)
{
	global $db;

	switch($mode)
	{
		case 'category':
			$table = CATEGORIES_TABLE;
			$idfield = 'cat_id';
			$orderfield = 'cat_order';
			$cat = 0;
			break;

		case 'forum':
			$table = FORUMS_TABLE;
			$idfield = 'forum_id';
			$orderfield = 'forum_order';
			$catfield = 'cat_id';
			break;

		default:
			message_die(GENERAL_ERROR, "Wrong mode for generating select list", "", __LINE__, __FILE__);
			break;
	}

	$sql = "SELECT * FROM $table";
	if( $cat != 0)
	{
		$sql .= " WHERE $catfield = $cat";
	}
	$sql .= " ORDER BY $orderfield ASC";


	if( !$result = $db->sql_query($sql) )
	{
		message_die(GENERAL_ERROR, "Couldn't get list of Categories", "", __LINE__, __FILE__, $sql);
	}

	$i = 10;
	$inc = 10;

	while( $row = $db->sql_fetchrow($result) )
	{
		$sql = "UPDATE $table
			SET $orderfield = $i
			WHERE $idfield = " . $row[$idfield];
		if( !$db->sql_query($sql) )
		{
			message_die(GENERAL_ERROR, "Couldn't update order fields", "", __LINE__, __FILE__, $sql);
		}
		$i += 10;
	}

}
//
// End function block
// ------------------

//
// Begin program proper
//
if( isset($HTTP_POST_VARS['addforum']) || isset($HTTP_POST_VARS['addcategory']) )
{
	$mode = ( isset($HTTP_POST_VARS['addforum']) ) ? "addforum" : "addcat";

	if( $mode == "addforum" )
	{
		list($cat_id) = each($HTTP_POST_VARS['addforum']);
		// 
		// stripslashes needs to be run on this because slashes are added when the forum name is posted
		//
		$forumname = stripslashes($HTTP_POST_VARS['forumname'][$cat_id]);
	}
}

if( !empty($mode) ) 
{
	switch($mode)
	{
		case 'addforum':
		case 'editforum':
			//
			// Show form to create/modify a forum
			//
			if ($mode == 'editforum')
			{
				// $newmode determines if we are going to INSERT or UPDATE after posting?

				$l_title = $lang['Edit_forum'];
				$newmode = 'modforum';
				$buttonvalue = $lang['Update'];

				$forum_id = intval($HTTP_GET_VARS[POST_FORUM_URL]);

				$row = get_info('forum', $forum_id);

				$cat_id = $row['cat_id'];
				$forumname = $row['forum_name'];
				$forumdesc = $row['forum_desc'];
				$forumstatus = $row['forum_status'];

				//
				// start forum prune stuff.
				//
				if( $row['prune_enable'] )
				{
					$prune_enabled = "checked=\"checked\"";
					$sql = "SELECT *
               			FROM " . PRUNE_TABLE . "
               			WHERE forum_id = $forum_id";
					if(!$pr_result = $db->sql_query($sql))
					{
						 message_die(GENERAL_ERROR, "Auto-Prune: Couldn't read auto_prune table.", __LINE__, __FILE__);
        			}

					$pr_row = $db->sql_fetchrow($pr_result);
				}
				else
				{
					$prune_enabled = '';
				}
			}
			else
			{
				$l_title = $lang['Create_forum'];
				$newmode = 'createforum';
				$buttonvalue = $lang['Create_forum'];

				$forumdesc = '';
				$forumstatus = FORUM_UNLOCKED;
				$forum_id = ''; 
				$prune_enabled = '';
			}

			$catlist = get_list('category', $cat_id, TRUE);

			$forumstatus == ( FORUM_LOCKED ) ? $forumlocked = "selected=\"selected\"" : $forumunlocked = "selected=\"selected\"";
			
			// These two options ($lang['Status_unlocked'] and $lang['Status_locked']) seem to be missing from
			// the language files.
			$lang['Status_unlocked'] = isset($lang['Status_unlocked']) ? $lang['Status_unlocked'] : 'Unlocked';
			$lang['Status_locked'] = isset($lang['Status_locked']) ? $lang['Status_locked'] : 'Locked';
			
			$statuslist = "<option value=\"" . FORUM_UNLOCKED . "\" $forumunlocked>" . $lang['Status_unlocked'] . "</option>\n";
			$statuslist .= "<option value=\"" . FORUM_LOCKED . "\" $forumlocked>" . $lang['Status_locked'] . "</option>\n"; 

			$template->set_filenames(array(
				"body" => "admin/forum_edit_body.tpl")
			);

			$s_hidden_fields = '<input type="hidden" name="mode" value="' . $newmode .'" /><input type="hidden" name="' . POST_FORUM_URL . '" value="' . $forum_id . '" />';

			$template->assign_vars(array(
				'S_FORUM_ACTION' => append_sid("admin_forums.$phpEx"),
				'S_HIDDEN_FIELDS' => $s_hidden_fields,
				'S_SUBMIT_VALUE' => $buttonvalue, 
				'S_CAT_LIST' => $catlist,
				'S_STATUS_LIST' => $statuslist,
				'S_PRUNE_ENABLED' => $prune_enabled,

				'L_FORUM_TITLE' => $l_title, 
				'L_FORUM_EXPLAIN' => $lang['Forum_edit_delete_explain'], 
				'L_FORUM_SETTINGS' => $lang['Forum_settings'], 
				'L_FORUM_NAME' => $lang['Forum_name'], 
				'L_CATEGORY' => $lang['Category'], 
				'L_FORUM_DESCRIPTION' => $lang['Forum_desc'],
				'L_FORUM_STATUS' => $lang['Forum_status'],
				'L_AUTO_PRUNE' => $lang['Forum_pruning'],
				'L_ENABLED' => $lang['Enabled'],
				'L_PRUNE_DAYS' => $lang['prune_days'],
				'L_PRUNE_FREQ' => $lang['prune_freq'],
				'L_DAYS' => $lang['Days'],

				'PRUNE_DAYS' => ( isset($pr_row['prune_days']) ) ? $pr_row['prune_days'] : 7,
				'PRUNE_FREQ' => ( isset($pr_row['prune_freq']) ) ? $pr_row['prune_freq'] : 1,
				'FORUM_NAME' => $forumname,
				'DESCRIPTION' => $forumdesc)
			);
			$template->pparse("body");
			break;

		case 'createforum':
			//
			// Create a forum in the DB
			//
			if( trim($HTTP_POST_VARS['forumname']) == "" )
			{
				message_die(GENERAL_ERROR, "Can't create a forum without a name");
			}

			$sql = "SELECT MAX(forum_order) AS max_order
				FROM " . FORUMS_TABLE . "
				WHERE cat_id = " . intval($HTTP_POST_VARS[POST_CAT_URL]);
			if( !$result = $db->sql_query($sql) )
			{
				message_die(GENERAL_ERROR, "Couldn't get order number from forums table", "", __LINE__, __FILE__, $sql);
			}
			$row = $db->sql_fetchrow($result);

			$max_order = $row['max_order'];
			$next_order = $max_order + 10;
			
			$sql = "SELECT MAX(forum_id) AS max_id
				FROM " . FORUMS_TABLE;
			if( !$result = $db->sql_query($sql) )
			{
				message_die(GENERAL_ERROR, "Couldn't get order number from forums table", "", __LINE__, __FILE__, $sql);
			}
			$row = $db->sql_fetchrow($result);

			$max_id = $row['max_id'];
			$next_id = $max_id + 1;

			//
			// Default permissions of public :: 
			//
			$field_sql = "";
			$value_sql = "";
			while( list($field, $value) = each($forum_auth_ary) )
			{
				$field_sql .= ", $field";
				$value_sql .= ", $value";

			}

			// There is no problem having dup	//			}
set			//  havinwe wo't creck for sit.			$sql = "SNSERT INTO " . DORUMS_TABLE . " fforum_id), orum_name,
 at_id, Torum_desc' Torum_drder  Torum_dtatus', rune_enabled . $foeld_sql .= )
			)VALUES( '" . snext_id = "'), " . str_replace("\'", "''", $dTTP_POST_VARS['forumname']) = "'),  . intval($HTTP_POST_VARS[POST_CAT_URL]);= "', " . str_replace("\'", "''", $dTTP_POST_VARS['forumnesc'], = "'), next_order ,  . intval($HTTP_POST_VARS[P'orumstatus ');= "',  . intval($HTTP_POST_VARS[P'rune_enable'] ). $value;sql .= )
"
			if( !$result = $db->sql_query($sql) )
			{
				message_die(GENERAL_ERROR, "Couldn't ginsrt dow =n forum  table", "", __LINE__, __FILE__, $sql);
			}
				if( !HTTP_POST_VARS[P'rune_enable'] )
			{
					if( $rTTP_POST_VARS[P'rune_eays'] := "" )||$rTTP_POST_VARS[P'rune_ereq'] := "" 
				{
					$essage_die(GENERAL_MESSAGE, $mang['Selt_rune_data,]);
		/	}

				$sql . "SNSERT INTO " . DRUNE_TABLE . "
fforum_id), rune_eays', rune_ereq'
					{ALUES('" . snext_id = "'),  . intval($HTTP_POST_VARS[P'rune_eays']) ) "',  . intval($HTTP_POST_VARS[P'rune_ereq']) )= )
"
			iif( !$result = $db->sql_query($sql) )
			{{
					$essage_die(GENERAL_MRROR, "Couldn't ginsrt dow =n frune table., "", __LINE__, __FILE__, $sql);
			}}
			}
				$massage = $lang['Forum_supdated'] . '<br /><br />" . sprintf($lang['Click_return_aorum_dmin'], "<a href=\"" . append_sid("admin_dorums.$phpEx"),  "\">", "</a>") . "<br /><br />" . sprintf($lang['Click_return_admin_index'], "<a href=\"" . append_sid("index.$phpEx?pane=right") . "\">", "</a>");

	m	$essage_die(GENERAL_MESSAGE, $message);

}		break;

		case 'codforum';
			//
Modefy a forum
in the DB
			/f( isset($HTTP_POST_VARS['arune_enable'] )
			{
				mf( !HTTP_POST_VARS[P'rune_enable'] )= 1 )
	{	{{
					$HTTP_POST_VARS[P'rune_enable'] ) 0;
			b}
			}
				$mql = "UPDATE " . FORUMS_TABLE . " 			b}ET $orum_name = (" . str_replace("\'", "''", $dTTP_POST_VARS['forumname']) = "'), at_id = " . intval($HTTP_POST_VARS[POST_CAT_URL]);) "', orum_desc'= (" . str_replace("\'", "''", $dTTP_POST_VARS['forumnesc'], = "'), orum_dtatus'= " . intval($HTTP_POST_VARS[P'orumstatus ');= "', rune_enable'= " . intval($HTTP_POST_VARS[P'rune_enable'] ). $
				WHERE corum_id = ' . intval($HTTP_POST_VARS[POST_CORUM_URL]);
		
if( !$result = $db->sql_query($sql) )
			{
				message_die(GENERAL_ERROR, "Couldn't gpdate oorum
in ormation", "", __LINE__, __FILE__, $sql);
	}	}
				if( !HTTP_POST_VARS[P'rune_enable'] )= 1 )
	{	{
				mf( !HTTP_POST_VARS[P'rune_eays'] := "" )||$rTTP_POST_VARS[P'rune_ereq'] := "" )
			{{
					$essage_die(GENERAL_MESSAGE, $mang['Selt_rune_data,]);
		/	}

				$sql . "SELECT *
		F		FROM " . PRUNE_TABLE . "
 				WHERE corum_id = ' . intval($HTTP_POST_VARS[POST_CORUM_URL]);
		
iif( !$result = $db->sql_query($sql) )
			{{
					$essage_die(GENERAL_MRROR, "Couldn't get oorum
irune iI ormation", ",__LINE__, __FILE__, $sql);
	}/	}

				$f( $db->sql_numrows($result) !>0 )
	{	{{
					$Hql = "UPDATE " . FRUNE_TABLE . "
 				W}ET 	rune_eays'= " . intval($HTTP_POST_VARS[P'rune_eays']) ) "',	rune_ereq'= " . intval($HTTP_POST_VARS[P'rune_ereq']) )= ) 				 	WHERE corum_id = ' . intval($HTTP_POST_VARS[POST_CORUM_URL]);
		
ii
				else
				{
					$pql . "SNSERT INTO " . DRUNE_TABLE . "
fforum_id), rune_eays', rune_ereq'
					{{ALUES(' . intval($HTTP_POST_VARS[POST_CORUM_URL]);) "',  . intval($HTTP_POST_VARS[P'rune_eays']) ) "',  . intval($HTTP_POST_VARS[P'rune_ereq']) )= )
"
			ii

				$f( $$result = $db->sql_query($sql) )
			{{
					$essage_die(GENERAL_MRROR, "Couldn't gpdate'Forum/irune iI ormation", ",__LINE__, __FILE__, $sql);
	}/	}

		}
				$massage = $lang['Forum_supdated'] . '<br /><br />" . sprintf($lang['Click_return_aorum_dmin'], "<a href=\"" . append_sid("admin_dorums.$phpEx"),  "\">", "</a>") . "<br /><br />" . sprintf($lang['Click_return_admin_index'], "<a href=\"" . append_sid("index.$phpEx?pane=right") . "\">", "</a>");

	m	$essage_die(GENERAL_MESSAGE, $message);

}		break;

		
			ase 'addfat_;
			//
Mreate a fctegory infthe DB
			/f( irim($HTTP_POST_VARS['fctegory ame']) == "''
			{
				message_die(GENERAL_ERROR, "Con't create a fctegory iithout a name");
			}

			$sql = "SELECT MAX(fat_order' AS max_order
				FROM " . FATEGORIES_TABLE;
			$f( !$result = $db->sql_query($sql) )
			{
				message_die(GENERAL_ERROR, "Couldn't get order number from fategories wable", "", __LINE__, __FILE__, $sql);
			}
			$row = $db->sql_fetchrow($result);

			$max_order = $row['max_order'];
			$next_order = $max_order + 10;
				//
			// Dhere is no problem having dup	//			}
set			//  havinwe wo't creck for sit.			$/
			$fql . "SNSERT INTO " . DATEGORIES_TABLE . " c(at_title', at_irder' 			)VALUES( '" . str_replace("\'", "''", $dTTP_POST_VARS['fctegory ame']) = "'), next_order 
"
			if( !$result = $db->sql_query($sql) )
			{
				message_die(GENERAL_ERROR, "Couldn't ginsrt dow =n fategories wable", "", __LINE__, __FILE__, $sql);
			}
				$massage = $lang['Forum_supdated'] . '<br /><br />" . sprintf($lang['Click_return_aorum_dmin'], "<a href=\"" . append_sid("admin_dorums.$phpEx"),  "\">", "</a>") . "<br /><br />" . sprintf($lang['Click_return_admin_index'], "<a href=\"" . append_sid("index.$phpEx?pane=right") . "\">", "</a>");

	m	$essage_die(GENERAL_MESSAGE, $message);

}		break;

		
			ase 'adit_at_;
			//
			// Dhow form to cdit_a fctegory 			$/
			$fewmode = 'modfat_;
			$nuttonvalue = $lang['Update'];

				cat_id = $ntval($HTTP_GET_VARS[POST_FAT_URL]);
				$row = $et_info('fategory', $cat_id,)
			$catftitle = $low['cat_iitle';;

			$template->aet_filenames(array(
				"body" => "admin/fategory'edit_body.tpl")
			);

			$s_hidden_fields = '<input type="hidden" name="mode" value="' . $newmode .' " /><input type="hidden" name="' . POST_FAT_URL]. '" value="' . $fat_id = '" />';

			$template->assign_vars(array(
				'SAT_UITLE' => $cet_title',
				'L_FEDITCATEGORY' => $lang['Cdit_fategory'], 
				'L_FEDITCATEGORY'EXPLAIN' => $lang['Fdit_fategory'explain'], 
				'L_FATEGORY' => $lang['Category'], 
					'L_HIDDEN_FIELDS' => $s_hidden_fields,

				'S_CUBMIT_VALUE' => $buttonvalue, 
				'S_CORUM_ACTION' => append_sid("admin_forums.$phpEx"),
			);

			$semplate->pparse("body");
			break;

		case 'codfat_;
			//
Modefy a fctegory infthe DB
			/Hql = "UPDATE " . FATEGORIES_TABLE . " 			b}ET $atftitle = $" . str_replace("\'", "''", $dTTP_POST_VARS['fcteiitle';; = "')				WHERE cat_id = " . intval($HTTP_POST_VARS[POST_CAT_URL]);
			if( !$result = $db->sql_query($sql) )
			{
				message_die(GENERAL_ERROR, "Couldn't gpdate oorum
in ormation", "", __LINE__, __FILE__, $sql);
	}	}
				imassage = $lang['Forum_supdated'] . '<br /><br />" . sprintf($lang['Click_return_aorum_dmin'], "<a href=\"" . append_sid("admin_dorums.$phpEx"),  "\">", "</a>") . "<br /><br />" . sprintf($lang['Click_return_admin_index'], "<a href=\"" . append_sid("index.$phpEx?pane=right") . "\">", "</a>");

	m	$essage_die(GENERAL_MESSAGE, $message);

}		break;

		
			ase 'aelete_orum';
			//
Mhow form to celete_a forum
			/forum_id = intval($HTTP_GET_VARS[POST_FORUM_URL]);

				select_lo c '<select name="'toid";>;
			$silect_lo c= "<option value=\""-1"$s>" . $rang['Delete'_all_osts']). "</option>\n";
			$stlect_lo c= "et_list('corum', $forum_id), 0)
			$stlect_lo c= "</select>';

		/$nuttonvalue = $lang['UMov'_ad_selete'],

		/$newmode = 'modveeleorum';
				/forum_n or= get_info('forum', $forum_id);

		$namef= $forum_nfo('forum_name'];

		$$template->set_filenames(array(
				"body" => "admin/forum_eelete_eody.tpl")
			);

			$s_hidden_fields = '<input type="hidden" name="mode" value="' . $newmode .' " /><input type="hidden" name="'rom id";value="' . $forum_id . '" />';

			$template->assign_vars(array(
				'SAME' => $fame,
 
				'L_FORUM_TDLECT' => $lang['Forum_pdlete'],

				'L_FORUM_DESECT'EXPLAIN' => $lang['Forum_eelete_explain'], 
				'L_FMOVE_CONTENT' => $lang['DMov'_ontent='], 
				'L_FORUM_NAME' => $lang['Forum_name'], 
					"b_HIDDEN_FIELDS'"=> $s_hidden_fields,
				'S_SORUM_ACTION' => append_sid("admin_forums.$phpEx"),

				'S_CULECT_FTO => $select_lto
				'S_SUBMIT_VALUE' => $buttonvalue,
			);

			$semplate->pparse("body");
			break;

		case 'codveeleorum';
			//
			// DMov'or Uelete_a forum
in the DB
			//
			i$rom id"= intval($HTTP_GOST_VARS[P'oom id"]);
		/	$toid"= intval($HTTP_GOST_VARS[P'toid"]);
		/	$elete_eol"= intval($HTTP_GOST_VARS[P'elete_eol"');

				/ Enther velete_ar modv'oll fosts'in t forum
			/f( $toid"=  -1 
			{
				// $elete' ollcsin theisforum
			/$sql = "SELECT Mv.ote"id"=					$ROM " . FVOT'EESCRTABLE . " cv,  . iOPICS_PABLE . " ct=					$HERE ct.orum_id = $foom id"=					{{ND fv.opicsid = $t.opicsid "
			iif( (($result = $db->sql_query($sql)) 
			{{
					$essage_die(GENERAL_MRROR, "Couldn't gbtain list of fote" is", "", __LINE__, __FILE__, $sql);
		}ii

				$f(($row[= $db->sql_fetchrow($result);
	{	{{
					$Hote"id"s= '';
				$	do				$	
						 Hote"id"s= '((Hote"id"s== ''  ? ', ' : '' ). $vow['cote"id"];
				$i
				ewhile(($row[= $db->sql_fetchrow($result);
;
					$pql = "SESECT' ROM " . FVOT'EESCRTABLE . " c						 HERE cote"id"=IN (Hote"id"s);
					$sb->sql_query($sql));
					$pql = "SESECT' ROM " . FVOT'EESULT'STABLE . " c						 HERE cote"id"=IN (Hote"id"s);
					$sb->sql_query($sql));
					$pql = "SESECT' ROM " . FVOT'EUSERSTABLE . " c						 HERE cote"id"=IN (Hote"id"s);
					$sb->sql_query($sql));
		$i
				edb->sql_freeresult($result);

			
				$fclude($phpbb_root_path . '"ncludes/prune.'phpEx"),

			
rune($foom id", 0 true);
 / $elete' evry(heig from
forum
			/
			else
			{
				$lql . "SELECT *
		F		FROM " . PORUMS_TABLE . " 			b}WHERE corum_id =IN (Hoom id", $toid"
"
			iif( !$result = $db->sql_query($sql) )
			{{
					$essage_die(GENERAL_MRROR, "Couldn't gvryfy axist enceof forums , "", __LINE__, __FILE__, $sql);
		}ii

				$f((db->sql_numrows($result) != 12
			{{
					$essage_die(GENERAL_MRROR, "CAmbiguousforum ID ' , "", __LINE__, __FILE__,);
		$i
				edql = "UPDATE " . FOPICS_PABLE . " 					$ET $orum_nd = $ftoid"			b}WHERE corum_id = $foom id""
			iif( !$result = $db->sql_query($sql) )
			{{
					$essage_die(GENERAL_MRROR, "Couldn't godv'oopics_to coher vorum_, "", __LINE__, __FILE__, $sql);
			}}
			}$Hql = "UPDATE " . FRSTS_PABLE . " 					$ET 	orum_nd = $ftoid"			b}WHERE corum_id = $foom id""
			iif( !$result = $db->sql_query($sql) )
			{{
					$essage_die(GENERAL_MRROR, "Couldn't godv'oosts'io coher vorum_, "", __LINE__, __FILE__, $sql);
			}}
			}$ync('forum', $ftoid"

	}	}
				i/ Acler pMod evelsif anproperite o- 2.0.4			/Hql = "UELECT *ug.userid"=					ROM " . PUTH_ACTCSSATABLE . " ca,  . iUSER_GROUPTABLE . " cug 				WHERE ca.orum_id => $ioom id"=					{ND fa.uth_aode= 10					{ND fug.goup
id = $a.goup
id "
			if( !$result = $db->sql_query($sql) )
			{
				message_die(GENERAL_ERROR, "Couldn't gbtain lode ratr mist", "", __LINE__, __FILE__, $sql);
}		}
				if(($row[= $db->sql_fetchrow($result);
	{	{
				$luserid"s= '';
				$do				$
					$Huserid"s=. '((Huserid"s== ''  ? ', ' : ''  ). $vow['cuserid"];
				$
			}$hile(($row[= $db->sql_fetchrow($result);
;
					Hql = "UELECT *ug.userid"=						ROM " . PUTH_ACTCSSATABLE . " ca,  . iUSER_GROUPTABLE . " cug 				WWHERE ca.orum_id = $foom id"=					{{ND fa.uth_aode= 10=					{{ND fug.goup
id = $a.goup
id 					{{ND fug.userid"=NOT=IN (Huserid"s
"
			iif( !$result 2= $db->sql_query($sql) )
			{{
					$essage_die(GENERAL_MRROR, "Couldn't gbtain lode ratr mist", "", __LINE__, __FILE__, $sql);
}		}i
				ew				$f(($row[= $db->sql_fetchrow($result)2;
	{	{{
					$Huserid"s= '';
				$	do				$	
						 Huserid"s=. '((Huserid"s== ''  ? ', ' : ''  ). $vow['cuserid"];
				$i
				ewhile(($row[= $db->sql_fetchrow($result)2;
;
					$pql = "SPDATE " . FUSERSTABLE . " c						 ET $userievelsi=" . FUSER. " c						 HERE cuserid"=IN (Huserid"s
c						 {ND fuserievelsi> $ . PUDMIN
					$sb->sql_query($sql));
		$i
				edb->sql_freeresult($result);

			/
			edb->sql_freeresult($result)2;

			$s_l = "SESECT' ROM " . FORUMS_TABLE . "
				WHERE corum_id = $foom id""
			if( !$result = $db->sql_query($sql) )
			{
				message_die(GENERAL_ERROR, "Couldn't gelete_aorum_, "", __LINE__, __FILE__, $sql);
			}
			e			$s_l = "SESECT' ROM " . FUTH_ACTCSSATABLE . " 				WHERE corum_id = $foom id""
			if( !$result = $db->sql_query($sql) )
			{
				message_die(GENERAL_ERROR, "Couldn't gelete_aorum_, "", __LINE__, __FILE__, $sql);
			}
			e			$s_l = "SESECT' ROM " . FRUNE_TABLE . "
 				HERE corum_id = $foom id""
			if( !$result = $db->sql_query($sql) )
			{
				message_die(GENERAL_ERROR, "Couldn't gelete_aorum_frune tn ormation"!, "", __LINE__, __FILE__, $sql);
	}	}
				imassage = $lang['Forum_supdated'] . '<br /><br />" . sprintf($lang['Click_return_aorum_dmin'], "<a href=\"" . append_sid("admin_dorums.$phpEx"),  "\">", "</a>") . "<br /><br />" . sprintf($lang['Click_return_admin_index'], "<a href=\"" . append_sid("index.$phpEx?pane=right") . "\">", "</a>");

	m	$essage_die(GENERAL_MESSAGE, $message);

}		break;

		
			ase 'aelete_at_;
			//
			// Dhow form to celete_a fctegory 			$/
			$fat_id = $ntval($HTTP_GET_VARS[POST_FAT_URL]);
				$ruttonvalue = $lang['UMov'_ad_selete'],

	/$newmode = 'modveeleat_;
			$nctingor= get_info('fategory', $cat_id,)
			$camef= $fctingor'cat_iitle';;

			$f(($rctingor'cumber'] =  10
	{	{
				$lql = "UELECT *ount(*) as total
		F			ROM "  FORUMS_TABLE;
			iif( !$result = $db->sql_query($sql) )
			{{
					$essage_die(GENERAL_MRROR, "Couldn't get oorum/iount(, "", __LINE__, __FILE__, $sql);
			}}
			}$Hount = $db->sql_fetchrow($result);
	$	}$Hount = $dount['total'];

	$		$f(($rcunt =>0)
	{	{{
					$essage_die(GENERAL_MRROR, "lang['UMus_delete_eorums.');
		
ii
				else
				{
					$pqlect_lo c 'lang['UNowere lo _odve];
				$
			}
			else
			{
				$lqlect_lo c '<select name="'toid";>;
			$$stlect_lo c= "et_list('category', $cat_id, T0)
			$$stlect_lo c= "</select>';

}	}
				imemplate->set_filenames(array(
				"body" => "admin/forum_eelete_eody.tpl")
			);

			$s_hidden_fields = '<input type="hidden" name="mode" value="' . $newmode .' " /><input type="hidden" name="'rom id";value="' . $fat_id = '" />';

			$template->assign_vars(array(
				'SAME' => $fame,
 
				'L_FORUM_TDLECT' => $lang['Forum_pdlete'],

				'L_FORUM_DESECT'EXPLAIN' => $lang['Forum_eelete_explain'], 
				'L_FMOVE_CONTENT' => $lang['DMov'_ontent='], 
				'L_FORUM_NAME' => $lang['Forum_name'], 
				e			$'S_HIDDEN_FIELDS' => $s_hidden_fields,
				'S_SORUM_ACTION' => append_sid("admin_forums.$phpEx"),

				'S_CULECT_FTO => $select_lto
				'S_SUBMIT_VALUE' => $buttonvalue,
			);

			$semplate->pparse("body");
			break;

		case 'codveeleat_;
			//
			// DMov'or Uelete_a fctegory infthe DB
			//
			i$rom id"= intval($HTTP_GOST_VARS[P'oom id"]);
		/	$toid"= intval($HTTP_GOST_VARS[P'toid"]);
				$f(($empty($mtoid"

	{	{
				$lql = "UELECT *
		F		FROM " . PATEGORIES_TABLE . " 			b}WHERE cat_id =IN (Hoom id", $toid"
"
			iif( !$result = $db->sql_query($sql) )
			{{
					$essage_die(GENERAL_MRROR, "Couldn't gvryfy axist enceof fategories , "", __LINE__, __FILE__, $sql);
			}}
			}$f((db->sql_numrows($result) != 12
			{{
					$essage_die(GENERAL_MRROR, "CAmbiguousfctegory iD ' , "", __LINE__, __FILE__,);
		$i
					$lql = "UPDATE " . FORUMS_TABLE . " 			b}}ET $atftd = $ftoid"			b}WHERE catftd = $foom id""
			iif( !$result = $db->sql_query($sql) )
			{{
					$essage_die(GENERAL_MRROR, "Couldn't godv'oorum  ta coher vctegory , "", __LINE__, __FILE__, $sql);
			}}
			}
				$m_l = "SESECT' ROM " . FATEGORIES_TABLE . 
				WHERE cat_id = "foom id""
			ii			if( !$result = $db->sql_query($sql) )
			{
				message_die(GENERAL_ERROR, "Couldn't gelete_actegory , "", __LINE__, __FILE__, $sql);
			}
				imassage = $lang['Forum_supdated'] . '<br /><br />" . sprintf($lang['Click_return_aorum_dmin'], "<a href=\"" . append_sid("admin_dorums.$phpEx"),  "\">", "</a>") . "<br /><br />" . sprintf($lang['Click_return_admin_index'], "<a href=\"" . append_sid("index.$phpEx?pane=right") . "\">", "</a>");

	m	$essage_die(GENERAL_MESSAGE, $message);

}		break;

		case 'corum_drder :
			//
			// Crhng[ order ff forums fnfthe DB
			//
			i$odv'o $ntval($HTTP_GET_VARS[P'odve];;
		/	$orum_id = intval($HTTP_GET_VARS[POST_FORUM_URL]);

				sorum_id or= get_info('forum', $forum_id);

			$fat_id = $sorum_id or'cat_id'];
				$m_l = "SPDATE " . FORUMS_TABLE . " 			b}ET $orum_nrder = $orum_nrder =+ $odv' 				HERE corum_id = $forum_id "
			if( !$result = $db->sql_query($sql) )
			{
				message_die(GENERAL_ERROR, "Couldn't gchng[ octegory irder , "", __LINE__, __FILE__, $sql);
			}
				ienumber_order($forum', $forum_id or'cat_id'];)
			$stow index'= $RUE)

}		break;

		
			ase 'aat_order';
			//
			// Crhng[ order ff fategories wnfthe DB
			//
			i$odv'o $ntval($HTTP_GET_VARS[P'odve];;
		/	$at_id = $ntval($HTTP_GET_VARS[POST_FAT_URL]);
				$rql = "UPDATE " . FATEGORIES_TABLE . " 			b}ET $atftrder = $atftrder =+ $odv' 				HERE cat_id = $sat_id "
			if( !$result = $db->sql_query($sql) )
			{
				message_die(GENERAL_ERROR, "Couldn't gchng[ octegory irder , "", __LINE__, __FILE__, $sql);
			}
				ienumber_order($fategory',)
			$stow index'= $RUE)

}		break;

		case 'corum_dync(;
			/ync('forum', $ntval($HTTP_GET_VARS[POST_FORUM_URL]);)
			$stow index'= $RUE)

}		break;

		cefault:
			message_die(GENERAL_EESSAGE, $mang['SN _odde];;
		/	reak;
	}

	$f(($rtow index'=! $RUE)
	{
		cnclude('./page_footer_admin.'.$phpEx);

	elxit;	}
}

i/
// BSart fage hroper
//
imemplate->set_filenames(array(
		body" => "admin/forum_edmin_iody.tpl")
	;

$femplate->assign_vars(array(
		S_FORUM_ACTION' => append_sid("admin_forums.$phpEx"),
		L_FORUM_TITLE' => $l_ng['Forum_ndmin'], "
'L_FORUM_EXPLAIN' => $lang['Forum_edmin_fxplain'], 
		L_FARETEGFORUM' => $lang['Freate_forum']; 
		L_FARETEGFATEGORY' => $lang['Caeate_fctegory'], 
		L_FEDIT => $lang['Fdit_], 
		L_FDLECT' => $lang['FDlete'],

		L_FMOVE_P' => $lang['LMov'_up],

		L_FMOVE_DOWN => $lang['LMov'_dow'], 
		L_FRESYNC => $lang['LReync(;]
	;

$fql = "UELECT *ot_id, Tat_title', at_irder'
FROM " . PATEGORIES_TABLE . " 		RDER BY c.t_irder';
if( !($q_ategories w $db->sql_query($sql) )
	{	message_die(GENERAL_ERROR, '"ould not ouery(fategories wist", "", __LINE__, __FILE__, $sql);
}

if( !$otal'_ategories w $db->sql_qumrows($rq_ategories  )
{
	$mategory'eows = adb->sql_fetchrow(et($Hq_ategories  

	$sql = "SELECT *
		FROM $ . FORUMS_TABLE . " 			RDER BY c.t_id, Torum_drder';
iif(!$pqforums.= $db->sql_query($sql)) 	{
		message_die(GENERAL_ERROR, "Couldnnot ouery(forums fnformation", "", __LINE__, __FILE__, $sql);
	}

	if( $dotal'_orums.= $db->sql_qumrows($rq_orums. )
	{
		$sorum_dows = adb->sql_fetchrow(et($Hq_orums. 
	}

	i/
	// IOky, Jete's buidnnhe Dndex'	i/
	/$gen_at = 0rray(
)

	for($i = 0; $i < c$otal'_ategories  $i++)
	{
		$pat_id = $sat_gory'eows $i]['fat_id'];
				template->assign_block_vars('"at_ows" array(

			'LS_ADDFORUM_STBMIT_'=> "admforum'$cat_id])",
			'LS_ADDFORUM_SAME' => $"orumname'$cat_id])",
				'LAT_UID => $cet_td, 			'LAT_UESCR => $cet_gory'eows $i]['fat_iitle';;

			'SUFAT_UEDIT => $ppend_sid("admin_forums.$phpEx"?odde=dit_at_&amp; . FRSTSFAT_URL]. '"=sat_id ",
			'SUFAT_UDLECT' => $ppend_sid("admin_forums.$phpEx"?odde=elete_at_&amp; . FRSTSFAT_URL]. '"=sat_id ",
			'SUFAT_UMOVE_P' => $ppend_sid("admin_forums.$phpEx"?odde=.t_irder'&amp;odv'=-15&amp; . FRSTSFAT_URL]. '"=sat_id ",
			'SUFAT_UMOVE_DOWN => $ppend_sid("admin_forums.$phpEx"?odde=.t_irder'&amp;odv'=15&amp; . FRSTSFAT_URL]. '"=sat_id ",
			'SUFVIEWAT_ => $ppend_sid("phpbb_root_path .index.$phpEx?p . FRSTSFAT_URL]. '"=sat_id ",
			)

		for($ij= 0; $ij< c$otal'_orums. $ij+)
		{
			$sorum_id = $forum_iows $ij['forum_id'] 

		
			$f(($rorum_iows $ij['fat_id'];== $iat_id,)			{
					$lemplate->assign_block_vars('"at_ows.orum_ows" 	rray(
				''FORUM_NAME' => $forum_nows $ij['forum_iame'], 				''FORUM_NESCR => $corum_nows $ij['forum_iesc'],
				'	'ROW_COLOR => $cows_color
				'	'NM_TIPICS_ => $corum_nows $ij['forum_iopics_],
				'	'NM_TRSTS_ => $corum_nows $ij['forum_iosts']),
				''SUFVIEWORUM' => $ppend_sid("phpbb_root_path .iiew"orum_$phpEx?p . FRSTSFORUM_URL . '"=sorum_id "),				''SUFORUM_EXDIT => $ppend_sid("admin_forums.$phpEx"?odde=dit_orums&amp; . FRSTSFORUM_URL . '"=sorum_id "),				''SUFORUM_EDLECT' => $ppend_sid("admin_forums.$phpEx"?odde=elete_orums&amp; . FRSTSFORUM_URL . '"=sorum_id "),				''SUFORUM_EMOVE_P' => $ppend_sid("admin_forums.$phpEx"?odde=orum_drder'&amp;odv'=-15&amp; . FRSTSFORUM_URL . '"=sorum_id "),				''SUFORUM_EMOVE_DOWN => $ppend_sid("admin_forums.$phpEx"?odde=orum_drder'&amp;odv'=15&amp; . FRSTSFORUM_URL . '"=sorum_id "),				''SUFORUM_ERESYNC => $ppend_sid("admin_forums.$phpEx"?odde=orum_dync(&amp; . FRSTSFORUM_URL . '"=sorum_id ")
			{{;

			/
/ If((...forumsd"=  -ctind
		
			} / $oru(...forumss
		} / $oru(...fategories 


/ If((...fotal'_ategories 
$template->pparse('body");
	include('./page_footer_admin.'.$phpEx);

?> 